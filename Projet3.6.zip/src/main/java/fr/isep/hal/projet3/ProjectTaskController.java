package fr.isep.hal.projet3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

// Contrôleur principal
public class ProjectTaskController {

    // Gestionnaire de projet
    private final ProjectManager projectManager;
    private final List<Employee> employeeList;

    public ProjectTaskController() {
        this.projectManager = new ProjectManager();
        this.employeeList = new ArrayList<>();
    }

    private final employeeManager employeeManager = new employeeManager();


    //Champ FXML
    @FXML
    private TextField projectIdField, projectNameField, projectDeadlineField;

    @FXML
    private TextField employeeIdField, employeeNameField, employeePositionField,employeeRoleField, employeeEmailField, employeePhoneField;
    @FXML
    private TextField assignTaskIdField;
    @FXML
    private TextField assignEmployeeIdField;

    @FXML
    private TextField taskIdField, taskNameField, taskPriorityField, taskDeadlineField, taskCategoryField;

    @FXML
    private TextArea taskDescriptionArea;

    @FXML
    private ListView<String> projectListView, employeeListView, taskListView;

    @FXML
    private Label resultLabel;

    private ObservableList<String> projectList;
    private ObservableList<String> taskObservableList;
    private ObservableList<String> employeeObservableList;


    @FXML
    public void initialize() {

        projectList = FXCollections.observableArrayList();
        employeeObservableList = FXCollections.observableArrayList();
        taskObservableList = FXCollections.observableArrayList();
        projectListView.setItems(projectList);
        employeeListView.setItems(employeeObservableList);
        taskListView.setItems(taskObservableList);


    }

    // Afficher une fenêtre contextuelle
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Vérifier le format de la date
    private boolean validateDate(String dateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);
            sdf.parse(dateStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    // Créer un projet
    @FXML
    protected void handleCreateProject() {
        try {
            String idText = projectIdField.getText();
            String name = projectNameField.getText();
            String deadline = projectDeadlineField.getText();

            if (idText.isEmpty() || name.isEmpty() || deadline.isEmpty() || !validateDate(deadline)) {
                showAlert("Erreur", "Veuillez entrer des informations de projet valides !");
                return;
            }

            int id = Integer.parseInt(idText); // Convertir l'ID
            projectManager.createProject(id, name, deadline); // Créer un projet

            projectList.add("ID: " + id + ", Nom: " + name); // Mettre à jour la liste
            resultLabel.setText("Le projet a été créé: " + name); // Afficher les résultats
        } catch (NumberFormatException e) {
            resultLabel.setText("Veuillez entrer un ID numérique valide！");
        }
    }

    //Éditer le projet
    @FXML
    protected void handleModifyProject() {
        String idText = projectIdField.getText();
        String name = projectNameField.getText();
        String deadline = projectDeadlineField.getText();

        if (idText.isEmpty() || name.isEmpty() || deadline.isEmpty() || !validateDate(deadline)) {
            showAlert("Erreur", "Veuillez entrer des informations de projet valides！");
            return;
        }

        int id = Integer.parseInt(idText);
        projectManager.modifyProject(id, name, deadline);
        resultLabel.setText("Le projet a été modifié: " + name);
    }

    // Supprimer le projet
    @FXML
    protected void handleDeleteProject() {
        String idText = projectIdField.getText();

        if (idText.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer l'ID du projet！");
            return;
        }

        int id = Integer.parseInt(idText);
        projectManager.deleteProject(id);
        projectList.removeIf(project -> project.startsWith("ID: " + id));
        resultLabel.setText("Le projet a été supprimé: ID = " + id);
    }

    // Créer une tâche
    @FXML
    protected void handleCreateTask() {
        String projectIdText = projectIdField.getText();
        String taskIdText = taskIdField.getText();
        String taskName = taskNameField.getText();
        String priority = taskPriorityField.getText();
        String deadline = taskDeadlineField.getText();
        String category = taskCategoryField.getText();
        String description = taskDescriptionArea.getText();

        if (projectIdText.isEmpty() || taskIdText.isEmpty() || taskName.isEmpty() || !validateDate(deadline)) {
            showAlert("Erreur", "Veuillez entrer des informations de tâche valides！");
            return;
        }



        int projectId = Integer.parseInt(projectIdText);
        int taskId = Integer.parseInt(taskIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("Erreur", "Aucun projet correspondant trouvé！");
            return;
        }

        fr.isep.hal.projet3.Task task = new fr.isep.hal.projet3.Task(taskId, taskName, priority, deadline, category, description);
        project.addTask(task);
        taskObservableList.add("La tâche a été créée: " + taskName);
        resultLabel.setText("La tâche a été créée: " + taskName);
        System.out.println("La tâche a été ajoutée à la liste: " + task.toString()); // Informations de débogage

    }


    @FXML
    protected void handleModifyTask() {
        String projectIdText = projectIdField.getText();
        String taskIdText = taskIdField.getText();
        String taskName = taskNameField.getText();
        String priority = taskPriorityField.getText();
        String deadline = taskDeadlineField.getText();
        String category = taskCategoryField.getText();
        String description = taskDescriptionArea.getText();

        if (projectIdText.isEmpty() || taskIdText.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer un ID de projet et un ID de tâche valides！");
            return;
        }

        int projectId = Integer.parseInt(projectIdText);
        int taskId = Integer.parseInt(taskIdText);

        // Rechercher un projet
        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("Erreur", "Aucun projet correspondant trouvé！");
            return;
        }

        // Rechercher une tâche
        fr.isep.hal.projet3.Task task = project.getTaskById(taskId);
        if (task == null) {
            showAlert("Erreur", "Aucune tâche correspondante trouvée！");
            return;
        }

        // Mettre à jour les informations de la tâche
        if (!taskName.isEmpty()) {
            task.setTaskName(taskName);  // Appeler une méthode d'instance en utilisant l'objet task
        }
        if (!priority.isEmpty()) {
            task.setPriority(priority);  // Appeler une méthode d'instance en utilisant l'objet task
        }
        if (!deadline.isEmpty() && validateDate(deadline)) {
            task.setDeadline(deadline);  // Appeler une méthode d'instance en utilisant l'objet task
        }
        if (!category.isEmpty()) {
            task.setCategory(category);
        }
        if (!description.isEmpty()) {
            task.setDescription(description);
        }

        //Mettre à jour la tâche dans le projet
        project.updateTask(task);

        int index = -1;
        for (int i = 0; i < taskObservableList.size(); i++) {
            if (taskObservableList.get(i).contains("ID: " + taskId)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            taskObservableList.set(index, task.toString());
        } else {
            System.out.println("Tâche non trouvée，ID: " + taskId);
        }

        // Afficher le message de succès de la modification
        resultLabel.setText("La tâche a été modifiée: " + taskName);
    }

    // Supprimer la tâche
    @FXML
    protected void handleDeleteTask() {
        String projectIdText = projectIdField.getText();
        String taskIdText = taskIdField.getText();

        if (projectIdText.isEmpty() || taskIdText.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer l'ID du projet et l'ID de la tâche！");
            return;
        }

        int projectId = Integer.parseInt(projectIdText);
        int taskId = Integer.parseInt(taskIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("Erreur", "Aucun projet correspondant trouvé！");
            return;
        }

        boolean removed = project.removeTask(taskId);
        if (removed) {
            taskObservableList.removeIf(task -> task.startsWith("ID: " + taskId));
            resultLabel.setText("La tâche a été supprimée: ID = " + taskId);
        } else {
            showAlert("Erreur", "Aucune tâche correspondante trouvée！");
        }
    }





    @FXML
    protected void handleCreateEmployee() {
        String employeeIdText = employeeIdField.getText();
        String employeeName = employeeNameField.getText();
        String employeePosition = employeePositionField.getText();
        String employeeRole = employeeRoleField.getText();
        String employeeEmail = employeeEmailField.getText();
        String employeePhone = employeePhoneField.getText();

        if (employeeIdText.isEmpty() || employeeName.isEmpty() || employeeRole.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer des informations d'employé valides！");
            return;
        }

        int employeeId = Integer.parseInt(employeeIdText);

        Employee employee = new Employee(employeeId, employeeName, employeeRole, employeeEmail, employeePhone,employeePosition);
        employeeManager.addEmployee(employee);
        employeeObservableList.add(employee.toString());
        resultLabel.setText("L'employé a été créé: " + employeeName);
    }


    @FXML
    protected void handleModifyEmployee() {
        String employeeIdText = employeeIdField.getText();
        String employeeName = employeeNameField.getText();
        String employeeRole = employeeRoleField.getText();
        String employeeEmail = employeeEmailField.getText();
        String employeePhone = employeePhoneField.getText();

        if (employeeIdText.isEmpty() || employeeName.isEmpty() || employeeRole.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer des informations d'employé valides！");
            return;
        }

        int employeeId = Integer.parseInt(employeeIdText);

        Employee employee = employeeManager.getEmployeeById(employeeId);
        if (employee == null) {
            showAlert("Erreur", "Aucun employé correspondant trouvé！");
            return;
        }

        employee.setName(employeeName);
        employee.setRole(employeeRole);
        employee.setEmail(employeeEmail);
        employee.setPhone(employeePhone);
        employeeObservableList.set(employeeObservableList.indexOf(employee.toString()), employee.toString());
        resultLabel.setText("L'employé a été modifié: " + employeeName);
    }

    @FXML
    protected void handleDeleteEmployee() {
        String employeeIdText = employeeIdField.getText();

        if (employeeIdText.isEmpty()) {
            showAlert("Erreur", "Veuillez saisir le numéro d'identification de l'employé！");
            return;
        }

        int employeeId = Integer.parseInt(employeeIdText);

        Employee employee = employeeManager.getEmployeeById(employeeId);
        if (employee == null) {
            showAlert("Erreur", "Aucun employé correspondant trouvé！");
            return;
        }

        boolean removed = employeeManager.removeEmployee(employeeId);
        if (removed) {
            employeeObservableList.removeIf(emp -> emp.startsWith("ID: " + employeeId));
            resultLabel.setText("Employé supprimé: ID = " + employeeId);
        } else {
            showAlert("Erreur", "Échec de la suppression, employé introuvable！");
        }
    }


    // Attribuer des tâches aux employés
    @FXML
    protected void handleAssignTask() {
        String employeeIdText = employeeIdField.getText();
        String taskIdText = taskIdField.getText();
        String projectIdText = projectIdField.getText();

        if (employeeIdText.isEmpty() || taskIdText.isEmpty() || projectIdText.isEmpty()) {
            showAlert("Erreur", "Veuillez entrer toutes les informations nécessaires！");
            return;
        }

        int employeeId = Integer.parseInt(employeeIdText);
        int taskId = Integer.parseInt(taskIdText);
        int projectId = Integer.parseInt(projectIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("Erreur", "Aucun élément correspondant trouvé！");
            return;
        }

        Task task = (Task) project.getTasks(taskId);
        if (task == null) {
            showAlert("Erreur", "Aucune tâche correspondante trouvée！");
            return;
        }

        Employee employee = findEmployeeById(employeeId);
        if (employee == null) {
            showAlert("Erreur", "Aucun employé correspondant trouvé！");
            return;
        }

        employee.addProject(project);
        task.assignTo(employee);
        resultLabel.setText("Tâche assignée: " + task.getTaskName() + " -> " + employee.getName());
    }

    // Trouver des employés
    private Employee findEmployeeById(int id) {
        for (Employee employee : employeeList) {
            if (employee.getId() == id) {
                return employee;
            }
        }
        return null;
    }
}
