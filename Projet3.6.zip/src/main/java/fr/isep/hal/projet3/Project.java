package fr.isep.hal.projet3;

import java.util.ArrayList;
import java.util.List;

public class Project {
    private int id;
    private String name;
    private String deadline;
    private List<Task> tasks = new ArrayList<>();;

    public Project() {
        tasks = new ArrayList<>();
    }

    // Obtenir la tâche selon l'ID de la tâche
    public Task getTasks(int taskId) {
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                return task;  // Trouver la tâche et la retourner
            }
        }
        return null;  // Si aucune tâche n'est trouvée, retourner null
    }

    public Project(int id, String name, String deadline) {
        this.id = id;
        this.name = name;
        this.deadline = deadline;
    }


    // Méthode pour ajouter une tâche
    public void addTask(Task task) {
        tasks.add(task);
    }
    // Mettre à jour la tâche
    public boolean updateTask(Task updatedTask) {
        // Rechercher une tâche selon l'ID de la tâche
        Task task = getTaskById(updatedTask.getTaskId());
        if (task != null) {
            //Si la tâche est trouvée, mettre à jour les champs de la tâche
            task.setTaskName(updatedTask.getTaskName());
            task.setPriority(updatedTask.getPriority());
            task.setDeadline(updatedTask.getDeadline());
            task.setCategory(updatedTask.getCategory());
            task.setDescription(updatedTask.getDescription());
            return true;  //Retourner true pour indiquer que la mise à jour a réussi
        }
        return false;  //Si aucune tâche n'est trouvée, retourner false
    }


    //Méthode pour obtenir une tâche
    public Task getTaskById(int taskId) {
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                return task;
            }
        }
        return null;
    }

    public boolean removeTask(int taskId) {
        // Parcourir la liste des tâches pour trouver la tâche à supprimer
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                // Supprimer la tâche après l'avoir trouvée
                tasks.remove(task);
                return true;  // Retourner true pour indiquer que la tâche a été supprimée avec succès
            }
        }
        return false;  // Si la tâche correspondante n'est pas trouvée, retourner false
    }
    // Méthodes Getter et Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    // Redéfinir la méthode toString
    @Override
    public String toString() {
        return "Project [ID=" + id + ", Name=" + name + ", Deadline=" + deadline + "]";
    }
}

