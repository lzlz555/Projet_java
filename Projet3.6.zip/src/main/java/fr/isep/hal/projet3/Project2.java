package fr.isep.hal.projet3;

class Project2 {
    private String name;
    private String description;

    public Project2(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @Override
    public String toString() {
        return "项目名称: " + name + ", 描述: " + description;
    }
}