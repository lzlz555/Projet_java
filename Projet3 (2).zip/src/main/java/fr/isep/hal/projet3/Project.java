package fr.isep.hal.projet3;

public class Project {
    private int id;
    private String name;
    private String deadline;

    public Project(int id, String name, String deadline) {
        this.id = id;
        this.name = name;
        this.deadline = deadline;
    }

    // Getter 和 Setter 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    // 重写 toString 方法
    @Override
    public String toString() {
        return "Project [ID=" + id + ", Name=" + name + ", Deadline=" + deadline + "]";
    }
}

