package fr.isep.hal.gestion_des_projets;

import java.util.HashMap;
import java.util.Map;

public class ProjectManager {
    private Map<Integer, Project> projectMap = new HashMap<>();

    // 创建项目
    public void createProject(int id, String name, String deadline) {
        Project project = new Project(id, name, deadline);
        projectMap.put(id, project);
    }

    // 修改项目
    public void modifyProject(int id, String name, String deadline) {
        Project project = projectMap.get(id);
        if (project != null) {
            project.setName(name);
            project.setDeadline(deadline);
        }
    }

    // 删除项目
    public void deleteProject(int id) {
        projectMap.remove(id);
    }

    // 查看项目
    public Project viewProject(int id) {
        return projectMap.get(id);
    }
}