package fr.isep.hal.projet3;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

// 主控制器
public class ProjectTaskController {

    // 项目管理器
    private final ProjectManager projectManager;
    private final List<Employee> employeeList;

    public ProjectTaskController() {
        this.projectManager = new ProjectManager();
        this.employeeList = new ArrayList<>();
    }

    // FXML字段
    @FXML
    private TextField projectIdField, projectNameField, projectDeadlineField;

    @FXML
    private TextField employeeIdField, employeeNameField, employeePositionField;

    @FXML
    private TextField taskIdField, taskNameField, taskPriorityField, taskDeadlineField, taskCategoryField;

    @FXML
    private TextArea taskDescriptionArea;

    @FXML
    private ListView<String> projectListView, employeeListView, taskListView;

    @FXML
    private Label resultLabel;

    private ObservableList<String> projectList = FXCollections.observableArrayList();
    private ObservableList<String> employeeObservableList = FXCollections.observableArrayList();
    private ObservableList<String> taskObservableList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        projectListView.setItems(projectList);
        employeeListView.setItems(employeeObservableList);
        taskListView.setItems(taskObservableList);
    }

    // 显示弹窗
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // 验证日期格式
    private boolean validateDate(String dateStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);
            sdf.parse(dateStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    // 创建项目
    @FXML
    protected void handleCreateProject() {
        String idText = projectIdField.getText();
        String name = projectNameField.getText();
        String deadline = projectDeadlineField.getText();

        if (idText.isEmpty() || name.isEmpty() || deadline.isEmpty() || !validateDate(deadline)) {
            showAlert("错误", "请输入有效的项目信息！");
            return;
        }

        int id = Integer.parseInt(idText);
        projectManager.createProject(id, name, deadline);
        projectList.add("ID: " + id + ", 名称: " + name);
        resultLabel.setText("项目已创建: " + name);
    }

    // 编辑项目
    @FXML
    protected void handleModifyProject() {
        String idText = projectIdField.getText();
        String name = projectNameField.getText();
        String deadline = projectDeadlineField.getText();

        if (idText.isEmpty() || name.isEmpty() || deadline.isEmpty() || !validateDate(deadline)) {
            showAlert("错误", "请输入有效的项目信息！");
            return;
        }

        int id = Integer.parseInt(idText);
        projectManager.modifyProject(id, name, deadline);
        resultLabel.setText("项目已修改: " + name);
    }

    // 删除项目
    @FXML
    protected void handleDeleteProject() {
        String idText = projectIdField.getText();

        if (idText.isEmpty()) {
            showAlert("错误", "请输入项目ID！");
            return;
        }

        int id = Integer.parseInt(idText);
        projectManager.deleteProject(id);
        projectList.removeIf(project -> project.startsWith("ID: " + id));
        resultLabel.setText("项目已删除: ID = " + id);
    }

    // 创建任务
    @FXML
    protected void handleCreateTask() {
        String projectIdText = projectIdField.getText();
        String taskIdText = taskIdField.getText();
        String taskName = taskNameField.getText();
        String priority = taskPriorityField.getText();
        String deadline = taskDeadlineField.getText();
        String category = taskCategoryField.getText();
        String description = taskDescriptionArea.getText();

        if (projectIdText.isEmpty() || taskIdText.isEmpty() || taskName.isEmpty() || !validateDate(deadline)) {
            showAlert("错误", "请输入有效的任务信息！");
            return;
        }

        int projectId = Integer.parseInt(projectIdText);
        int taskId = Integer.parseInt(taskIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("错误", "未找到对应项目！");
            return;
        }

        Task task = new Task(taskId, taskName, priority, deadline, category, description);
        project.addTask(task);
        taskObservableList.add(task.toString());
        resultLabel.setText("任务已创建: " + taskName);
    }

    // 删除任务
    @FXML
    protected void handleDeleteTask() {
        String projectIdText = projectIdField.getText();
        String taskIdText = taskIdField.getText();

        if (projectIdText.isEmpty() || taskIdText.isEmpty()) {
            showAlert("错误", "请输入项目ID和任务ID！");
            return;
        }

        int projectId = Integer.parseInt(projectIdText);
        int taskId = Integer.parseInt(taskIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("错误", "未找到对应项目！");
            return;
        }

        boolean removed = project.removeTask(taskId);
        if (removed) {
            taskObservableList.removeIf(task -> task.startsWith("ID: " + taskId));
            resultLabel.setText("任务已删除: ID = " + taskId);
        } else {
            showAlert("错误", "未找到对应任务！");
        }
    }

    // 分配任务给员工
    @FXML
    protected void handleAssignTask() {
        String employeeIdText = employeeIdField.getText();
        String taskIdText = taskIdField.getText();
        String projectIdText = projectIdField.getText();

        if (employeeIdText.isEmpty() || taskIdText.isEmpty() || projectIdText.isEmpty()) {
            showAlert("错误", "请输入所有必要信息！");
            return;
        }

        int employeeId = Integer.parseInt(employeeIdText);
        int taskId = Integer.parseInt(taskIdText);
        int projectId = Integer.parseInt(projectIdText);

        Project project = projectManager.viewProject(projectId);
        if (project == null) {
            showAlert("错误", "未找到对应项目！");
            return;
        }

        Task task = project.getTask(taskId);
        if (task == null) {
            showAlert("错误", "未找到对应任务！");
            return;
        }

        Employee employee = findEmployeeById(employeeId);
        if (employee == null) {
            showAlert("错误", "未找到对应员工！");
            return;
        }

        employee.addProject(project);
        task.assignTo(employee);
        resultLabel.setText("任务已分配: " + task.getName() + " -> " + employee.getName());
    }

    // 查找员工
    private Employee findEmployeeById(int id) {
        for (Employee employee : employeeList) {
            if (employee.getId() == id) {
                return employee;
            }
        }
        return null;
    }
}
