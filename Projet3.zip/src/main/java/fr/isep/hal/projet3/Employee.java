package idea.demo2;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
class Employee {
    private static int idCounter = 1;
    private int id;
    private String name;
    private String position;
    private List<Project> projectHistory;

    public Employee(String name, String position) {
        this.id = idCounter++;
        this.name = name;
        this.position = position;
        this.projectHistory = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public List<Project> getProjectHistory() {
        return projectHistory;
    }

    public void addProject(Project project) {
        projectHistory.add(project);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", 姓名: " + name + ", 职位: " + position;
    }
}