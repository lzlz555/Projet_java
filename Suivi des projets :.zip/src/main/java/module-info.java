module idea.demo2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens idea.demo2 to javafx.fxml;
    exports idea.demo2;
}