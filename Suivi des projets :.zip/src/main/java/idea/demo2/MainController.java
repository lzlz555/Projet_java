package idea.demo2;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class MainController {

    @FXML
    private void handlePersonnel() {
        showAlert("人员管理", "打开人员管理模块。");
    }

    @FXML
    private void handleProject() {
        showAlert("项目管理", "打开项目管理模块。");
    }

    @FXML
    private void handleTask() {
        showAlert("任务管理", "打开任务管理模块。");
    }

    @FXML
    private void handleTracking() {
        showAlert("项目跟踪", "打开项目跟踪模块。");
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
