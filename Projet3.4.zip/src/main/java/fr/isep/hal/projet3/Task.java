package fr.isep.hal.projet3;

public class Task {
    private int taskId;
    private String taskName;
    private String priority;
    private String deadline;
    private String category;
    private String description;
    private Employee assignedEmployee;

    // 构造函数
    public Task(int taskId, String taskName, String priority, String deadline, String category, String description) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.priority = priority;
        this.deadline = deadline;
        this.category = category;
        this.description = description;
        this.assignedEmployee = null;
    }

    // Getter 和 Setter
    public int getTaskId() {
        return taskId;
    }




    public void assignTo(Employee employee) {
        this.assignedEmployee = employee;  // 将任务分配给指定的员工
    }

    // 获取已分配员工的名称
    public String getAssignedEmployeeName() {
        return assignedEmployee != null ? assignedEmployee.getName() : "未分配";
    }


    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getCategory() {
        return category;
    }

    public  void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "任务ID: " + taskId + ", 名称: " + taskName + ", 优先级: " + priority + ", 截止日期: " + deadline + ", 类别: " + category + ", 描述: " + description;
    }
}

