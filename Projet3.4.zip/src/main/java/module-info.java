module fr.isep.hal.projet3 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens fr.isep.hal.projet3 to javafx.fxml;
    exports fr.isep.hal.projet3;
}