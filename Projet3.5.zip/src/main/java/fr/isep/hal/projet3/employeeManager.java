package fr.isep.hal.projet3;

import java.util.HashMap;
import java.util.Map;

public class employeeManager {
    private final Map<Integer, Employee> employeeMap;

    public employeeManager() {
        employeeMap = new HashMap<>();
    }

    // Method to add an employee
    public void addEmployee(Employee employee) {
        int id = employee.getId();
        employeeMap.put(id, employee);
    }

    // Method to get an employee by ID
    public Employee getEmployeeById(int id) {
        return employeeMap.get(id);
    }

    // Method to remove an employee by ID
    public boolean removeEmployee(int id) {
        if (employeeMap.containsKey(id)) {
            employeeMap.remove(id);
            return true;
        }
        return false;
    }
}
