package fr.isep.hal.projet3;

import java.util.ArrayList;
import java.util.List;

public class Project {
    private int id;
    private String name;
    private String deadline;
    private List<Task> tasks = new ArrayList<>();;

    public Project() {
        tasks = new ArrayList<>();
    }

    // 根据任务ID获取任务
    public Task getTasks(int taskId) {
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                return task;  // 找到任务并返回
            }
        }
        return null;  // 如果没有找到任务，返回 null
    }

    public Project(int id, String name, String deadline) {
        this.id = id;
        this.name = name;
        this.deadline = deadline;
    }


    // 添加任务的方法
    public void addTask(Task task) {
        tasks.add(task);
    }
    // 更新任务
    public boolean updateTask(Task updatedTask) {
        // 根据任务ID查找任务
        Task task = getTaskById(updatedTask.getTaskId());
        if (task != null) {
            // 如果找到了任务，更新任务的字段
            task.setTaskName(updatedTask.getTaskName());
            task.setPriority(updatedTask.getPriority());
            task.setDeadline(updatedTask.getDeadline());
            task.setCategory(updatedTask.getCategory());
            task.setDescription(updatedTask.getDescription());
            return true;  // 返回true表示更新成功
        }
        return false;  // 如果没有找到任务，返回false
    }


    // 获取任务的方法
    public Task getTaskById(int taskId) {
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                return task;
            }
        }
        return null;
    }

    public boolean removeTask(int taskId) {
        // 遍历任务列表，查找要删除的任务
        for (Task task : tasks) {
            if (task.getTaskId() == taskId) {
                // 找到任务后移除
                tasks.remove(task);
                return true;  // 返回 true 表示任务删除成功
            }
        }
        return false;  // 如果没有找到对应的任务，返回 false
    }
    // Getter 和 Setter 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    // 重写 toString 方法
    @Override
    public String toString() {
        return "Project [ID=" + id + ", Name=" + name + ", Deadline=" + deadline + "]";
    }
}

