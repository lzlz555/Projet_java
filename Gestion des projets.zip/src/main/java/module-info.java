module fr.isep.hal.gestion_des_projets {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;

    opens fr.isep.hal.gestion_des_projets to javafx.fxml;
    exports fr.isep.hal.gestion_des_projets;
}