package fr.isep.hal.gestion_des_projets;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ProjectController {

    // 控件绑定
    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField deadlineField;

    @FXML
    private Label resultLabel;

    private final ProjectManager projectManager;

    public ProjectController() {
        this.projectManager = new ProjectManager();
    }

    // 显示警告框
    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // 验证输入字段
    private boolean validateInputs() {
        if (idField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty() || deadlineField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "输入错误", "所有字段都必须填写！");
            return false;
        }
        // 可能需要验证日期格式
        try {
            String deadline = deadlineField.getText();
            // 检查日期格式（此处假设日期格式为 yyyy-MM-dd）
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            sdf.setLenient(false);
            sdf.parse(deadline);
        } catch (ParseException e) {
            showAlert(Alert.AlertType.ERROR, "日期格式错误", "请输入有效的日期格式（yyyy-MM-dd）！");
            return false;
        }
        return true;
    }

    // 创建项目
    @FXML
    protected void handleCreateProject() {
        if (!validateInputs()) {
            return;
        }

        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String deadline = deadlineField.getText();

            projectManager.createProject(id, name, deadline);
            resultLabel.setText("项目已创建: ID = " + id + ", 名称 = " + name + ", 截止日期 = " + deadline);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "错误", "项目ID必须是数字！");
        }
    }

    // 修改项目
    @FXML
    protected void handleModifyProject() {
        if (!validateInputs()) {
            return;
        }

        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String deadline = deadlineField.getText();

            projectManager.modifyProject(id, name, deadline);
            resultLabel.setText("项目已修改: ID = " + id + ", 新名称 = " + name + ", 新截止日期 = " + deadline);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "错误", "项目ID必须是数字！");
        }
    }

    // 删除项目
    @FXML
    protected void handleDeleteProject() {
        if (idField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "输入错误", "项目ID不能为空！");
            return;
        }

        try {
            int id = Integer.parseInt(idField.getText());
            projectManager.deleteProject(id);
            resultLabel.setText("项目已删除: ID = " + id);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "错误", "项目ID必须是数字！");
        }
    }

    // 查看项目
    @FXML
    protected void handleViewProject() {
        if (idField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "输入错误", "项目ID不能为空！");
            return;
        }

        try {
            int id = Integer.parseInt(idField.getText());
            Project project = projectManager.viewProject(id);
            if (project != null) {
                resultLabel.setText("项目信息: " + project);
            } else {
                showAlert(Alert.AlertType.WARNING, "未找到项目", "没有找到ID为 " + id + " 的项目！");
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "错误", "项目ID必须是数字！");
        }
    }
}