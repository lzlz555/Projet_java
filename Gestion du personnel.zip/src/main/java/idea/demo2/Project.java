package idea.demo2;

class Project {
    private String name;
    private String description;

    public Project(String name, String description) {
        this.name = name;
        this.description = description;
    }

    @Override
    public String toString() {
        return "项目名称: " + name + ", 描述: " + description;
    }
}