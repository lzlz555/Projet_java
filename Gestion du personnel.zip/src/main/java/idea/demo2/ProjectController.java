package idea.demo2;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

import java.util.ArrayList;
import java.util.List;

public class ProjectController {

    // 用于存储员工的列表
    private List<Employee> employeeList = new ArrayList<>();

    // FXML 输入字段
    @FXML
    private TextField employeeIdField;

    @FXML
    private TextField employeeNameField;

    @FXML
    private TextField employeePositionField;

    // 创建员工
    @FXML
    private void createEmployee() {
        String name = employeeNameField.getText();
        String position = employeePositionField.getText();

        if (name.isEmpty() || position.isEmpty()) {
            showAlert("错误", "姓名和职位不能为空！");
            return;
        }

        Employee employee = new Employee(name, position);
        employeeList.add(employee);
        showAlert("成功", "员工已创建：\n" + employee);
        clearInputFields();
    }

    // 编辑员工
    @FXML
    private void editEmployee() {
        String idText = employeeIdField.getText();
        String newName = employeeNameField.getText();
        String newPosition = employeePositionField.getText();

        if (idText.isEmpty()) {
            showAlert("错误", "请输入员工ID！");
            return;
        }

        int id = Integer.parseInt(idText);
        Employee employee = findEmployeeById(id);

        if (employee == null) {
            showAlert("错误", "未找到该员工！");
            return;
        }

        if (!newName.isEmpty()) employee.setName(newName);
        if (!newPosition.isEmpty()) employee.setPosition(newPosition);

        showAlert("成功", "员工信息已更新：\n" + employee);
        clearInputFields();
    }

    // 删除员工
    @FXML
    private void deleteEmployee() {
        String idText = employeeIdField.getText();

        if (idText.isEmpty()) {
            showAlert("错误", "请输入员工ID！");
            return;
        }

        int id = Integer.parseInt(idText);
        Employee employee = findEmployeeById(id);

        if (employee == null) {
            showAlert("错误", "未找到该员工！");
            return;
        }

        employeeList.remove(employee);
        showAlert("成功", "员工已删除：\n" + employee);
        clearInputFields();
    }

    // 查看员工信息
    @FXML
    private void viewEmployee() {
        String idText = employeeIdField.getText();

        if (idText.isEmpty()) {
            showAlert("错误", "请输入员工ID！");
            return;
        }

        int id = Integer.parseInt(idText);
        Employee employee = findEmployeeById(id);

        if (employee == null) {
            showAlert("错误", "未找到该员工！");
            return;
        }

        showAlert("员工信息", "员工详情：\n" + employee);
    }

    // 查看员工历史记录
    @FXML
    private void viewEmployeeHistory() {
        String idText = employeeIdField.getText();

        if (idText.isEmpty()) {
            showAlert("错误", "请输入员工ID！");
            return;
        }

        int id = Integer.parseInt(idText);
        Employee employee = findEmployeeById(id);

        if (employee == null) {
            showAlert("错误", "未找到该员工！");
            return;
        }

        List<Project> history = employee.getProjectHistory();
        if (history.isEmpty()) {
            showAlert("员工历史记录", "该员工没有完成的项目记录！");
        } else {
            StringBuilder historyDetails = new StringBuilder("员工项目历史记录：\n");
            for (Project project : history) {
                historyDetails.append(project).append("\n");
            }
            showAlert("员工历史记录", historyDetails.toString());
        }
    }

    // 显示弹窗
    private void showAlert(String title, String message) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // 通过ID查找员工
    private Employee findEmployeeById(int id) {
        for (Employee employee : employeeList) {
            if (employee.getId() == id) {
                return employee;
            }
        }
        return null;
    }

    // 清空输入字段
    private void clearInputFields() {
        employeeIdField.clear();
        employeeNameField.clear();
        employeePositionField.clear();
    }
}
